package com.example.cafevensong.Domain

data class BannerModel(val url:String="")
