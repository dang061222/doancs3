package com.example.cafevensong.Domain

data class CategoryModel(val title:String="",val id: Int = 0)
